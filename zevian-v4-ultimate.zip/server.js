require('dotenv').config();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const TelegramBot = require('node-telegram-bot-api');

const app = express();
app.use(cors());
app.use(express.json({
  limit: '3mb',
  verify: (req, res, buf) => { req.rawBody = buf; }
}));
app.use(express.static(path.join(__dirname, 'public')));

const GRAPH_VERSION = 'v21.0';
const ADMIN_CHAT_ID = (process.env.TELEGRAM_ADMIN_CHAT_ID || '').trim();
const BOT_TOKEN = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
const GEMINI_API_KEY = (process.env.GEMINI_API_KEY || '').trim();
const PAGE_TOKEN = (process.env.FB_PAGE_ACCESS_TOKEN || '').trim();
const APP_SECRET = (process.env.FB_APP_SECRET || '').trim();
const ADMIN_PASSWORD = (process.env.ADMIN_PASSWORD || 'zevian2026').trim();
const PUBLIC_URL = (process.env.PUBLIC_URL || 'https://fb-gemini-autoreply.onrender.com').replace(/\/+$/, '');
const DATA_DIR = path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'zevian_v4_state.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const defaultState = {
  config: {
    assistantName: 'ZEVIAN',
    ownerDisplayName: 'সাফি স্যার',
    masterActive: true,
    pageDmEnabled: true,
    commentReplyEnabled: true,
    commentInboxEnabled: true,
    pronounMatching: true,
    confidenceThreshold: 0.72,
    defaultTone: 'Casual & Friendly',
    emojiLevel: 'Light',
    systemPrompt:
      'You are ZEVIAN, a natural, warm, friend-like AI personal Messenger assistant for this Facebook Page. Match the sender\'s language (Bengali, English, or Banglish) and pronoun style (তুই -> তুই, তুমি -> তুমি, আপনি -> আপনি). Be concise (1-3 sentences), natural, and conversational — never sound like a robotic FAQ support bot. NEVER invent personal plans, location, eating status, or decisions.'
  },
  ownerStatuses: [],
  ownerMemories: [],
  kbItems: [
    {
      id: 'kb-1',
      question: 'ZEVIAN কী?',
      answer: 'ZEVIAN হলো এই ফেসবুক পেজের এআই পার্সোনাল মেসেঞ্জার অ্যাসিস্ট্যান্ট, যে স্বাভাবিকভাবে কথা বলে এবং ব্যক্তিগত প্রশ্নগুলো সরাসরি Owner-এর কাছে পৌঁছে দেয়।'
    }
  ],
  conversations: {},
  pendingReplies: {},
  blockedUsers: [],
  errorLogs: [],
  stats: { totalIn: 0, autoReplied: 0, escalated: 0, ownerReplied: 0 },
  pendingCounter: 1000,
  statusCounter: 100
};

let state = JSON.parse(JSON.stringify(defaultState));
if (fs.existsSync(STATE_FILE)) {
  try {
    const loaded = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    state = {
      ...state,
      ...loaded,
      config: { ...defaultState.config, ...(loaded.config || {}) },
      stats: { ...defaultState.stats, ...(loaded.stats || {}) }
    };
  } catch (_) {}
}

function saveState() {
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8'); } catch (_) {}
}

function recordError(source, detail) {
  state.errorLogs.unshift({
    time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    source,
    detail: String(detail).slice(0, 300)
  });
  if (state.errorLogs.length > 60) state.errorLogs = state.errorLogs.slice(0, 60);
  saveState();
}

const PERSONAL_CUES = [
  'কোথায় আছ', 'কোথায় আছ', 'কলেজে যাব', 'খেয়েছিস', 'খেয়েছিস', 'খেয়েছো', 'খেয়েছো',
  'ফোন দিবো', 'ফোন দেবো', 'ফোন দিতে পারি', 'আজকে আসব', 'কালকে আসব', 'দেখা করতে পারব',
  'বাসায় আছ', 'বাসায় আছ', 'কখন আসব', 'চিনতে পারছ', 'তুমি কি রাজি', 'kothay ach',
  'phone dibo', 'kalke asb', 'basay ach', 'ki diye kheye', 'khaichis', 'kothay tui'
];

const STATUS_TRIGGER_CUES = [
  'বাইরে যাচ্ছি', 'ব্যস্ত আছি', 'ব্যস্ত থাকব', 'কলেজে যাচ্ছি', 'খেয়ে নিয়েছি', 'খেয়ে নিয়েছি',
  'অনলাইনে থাকব না', 'পাওয়া যাবে না', 'পাওয়া যাবে না', 'ঘুমাচ্ছি', 'মিটিংয়ে আছি', 'মিটিংয়ে আছি'
];

const processedIds = new Set();
let activeReplyPendingId = null;
let pendingDraftStatus = null;
let lastGeminiError = null;
let tgBot = null;

// --- Active Non-Expired Shareable Statuses ---
function getActiveShareableStatuses() {
  const now = Date.now();
  let changed = false;
  state.ownerStatuses.forEach(st => {
    if (st.active && st.expiresAt && now > st.expiresAt) {
      st.active = false;
      changed = true;
    }
  });
  if (changed) saveState();
  return state.ownerStatuses.filter(st => st.active && st.visibility === 'shareable');
}

function addOwnerStatus(text, visibility, durationMinutes) {
  state.statusCounter += 1;
  const now = Date.now();
  const expiresAt = durationMinutes ? now + durationMinutes * 60000 : null;
  const st = {
    id: `ST-${state.statusCounter}`,
    text: text.trim(),
    visibility: visibility === 'private' ? 'private' : 'shareable',
    active: true,
    createdAt: new Date(now).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    expiresAt,
    expiresLabel: durationMinutes ? `${durationMinutes}m` : 'Manual'
  };
  state.ownerStatuses.unshift(st);
  if (state.ownerStatuses.length > 30) state.ownerStatuses = state.ownerStatuses.slice(0, 30);
  saveState();
  return st;
}

// --- Security Helpers ---
function verifyMetaSignature(req) {
  if (!APP_SECRET) return true;
  const sig = req.headers['x-hub-signature-256'];
  if (!sig || !req.rawBody) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', APP_SECRET).update(req.rawBody).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected)); } catch (_) { return false; }
}

function verifyTelegramInitData(initData) {
  if (!initData || !BOT_TOKEN) return false;
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');
    if (!hash) return false;
    params.delete('hash');
    const dataCheckString = Array.from(params.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`)
      .join('\n');
    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(BOT_TOKEN).digest();
    const calcHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
    if (calcHash !== hash) return false;
    const userRaw = params.get('user');
    if (ADMIN_CHAT_ID && userRaw) {
      const user = JSON.parse(userRaw);
      if (String(user.id) !== String(ADMIN_CHAT_ID)) return false;
    }
    return true;
  } catch (_) {
    return false;
  }
}

// --- Meta Graph API Helpers ---
async function callGraph(endpoint, payload) {
  if (!PAGE_TOKEN) return { error: 'Missing FB_PAGE_ACCESS_TOKEN' };
  try {
    const url = `https://graph.facebook.com/${GRAPH_VERSION}/${endpoint}?access_token=${encodeURIComponent(PAGE_TOKEN)}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data && data.error) recordError('Meta API', data.error.message || JSON.stringify(data.error));
    return data;
  } catch (e) {
    recordError('Meta API', e.message);
    return { error: e.message };
  }
}

async function fetchSenderName(psid) {
  if (!PAGE_TOKEN) return `User ${psid.slice(-4)}`;
  try {
    const res = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${psid}?fields=first_name,last_name&access_token=${encodeURIComponent(PAGE_TOKEN)}`);
    const data = await res.json();
    if (data && data.first_name) return `${data.first_name} ${data.last_name || ''}`.trim();
  } catch (_) {}
  return `User ${psid.slice(-4)}`;
}

// --- Conversation & Contact Preferences ---
function getOrCreateConv(psid, senderName) {
  if (!state.conversations[psid]) {
    state.conversations[psid] = {
      psid,
      senderName: senderName || `User ${psid.slice(-4)}`,
      lastUserAt: Date.now(),
      prefs: { language: 'auto', pronoun: 'auto', tone: 'auto' },
      summary: '',
      messages: []
    };
  } else if (senderName && state.conversations[psid].senderName.startsWith('User ')) {
    state.conversations[psid].senderName = senderName;
  }
  return state.conversations[psid];
}

function detectPronounAndLang(text, conv) {
  const t = (text || '').trim();
  const low = t.toLowerCase();
  if (/[\u0980-\u09FF]/.test(t)) conv.prefs.language = 'bn';
  else if (/\b(ki|koris|kemon|acho|valo|tui|tumi|apni|kothay|khobor|kalke|ajke|bhai)\b/.test(low)) conv.prefs.language = 'banglish';
  else if (/[a-zA-Z]{3,}/.test(t)) conv.prefs.language = 'en';

  if (/\b(tui|tor|koris|achis|khaichis|jabi|asbi)\b/.test(low) || /(তুই|তোর|করিস|আছিস|খেয়েছিস|খেয়েছিস|যাবি|আসবি)/.test(t)) {
    conv.prefs.pronoun = 'তুই (casual)';
  } else if (/\b(apni|apnar|korchen|achen)\b/.test(low) || /(আপনি|আপনার|করছেন|আছেন)/.test(t)) {
    conv.prefs.pronoun = 'আপনি (formal)';
  } else if (/\b(tumi|tomar|korcho|acho)\b/.test(low) || /(তুমি|তোমার|করছ|আছো)/.test(t)) {
    conv.prefs.pronoun = 'তুমি (friendly)';
  }
}

function pushHistory(psid, role, text) {
  const conv = getOrCreateConv(psid);
  if (role === 'User') {
    conv.lastUserAt = Date.now();
    detectPronounAndLang(text, conv);
  }
  conv.messages.push({ role, text, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) });
  if (conv.messages.length > 25) {
    const older = conv.messages.slice(0, 5).map(m => `${m.role}: ${m.text}`).join(' | ');
    conv.summary = (conv.summary ? conv.summary + ' ; ' : '') + older.slice(0, 260);
    conv.messages = conv.messages.slice(-20);
  }
  saveState();
}

function isWithin24hWindow(psid) {
  const conv = state.conversations[psid];
  return !conv || !conv.lastUserAt || (Date.now() - conv.lastUserAt) < 86400000;
}

function isObviousPersonal(text) {
  const low = (text || '').toLowerCase();
  return PERSONAL_CUES.some(cue => low.includes(cue));
}

// --- Gemini Free-Tier Multi-Model Engine ---
async function callGeminiJSON(promptText, temperature = 0.65) {
  if (!GEMINI_API_KEY) {
    lastGeminiError = 'GEMINI_API_KEY is missing';
    recordError('Gemini', lastGeminiError);
    return null;
  }
  const modelsToTry = ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-3.6-flash', 'gemini-3.8-flash'];
  for (const model of modelsToTry) {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: promptText }] }],
            generationConfig: { temperature, responseMimeType: 'application/json' }
          })
        }
      );
      const data = await res.json();
      if (!res.ok) {
        lastGeminiError = `${model} HTTP ${res.status}: ${data.error ? data.error.message : 'Error'}`;
        continue;
      }
      const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (rawText) {
        lastGeminiError = null;
        return JSON.parse(rawText.replace(/^```json\s*/i, '').replace(/```$/i, '').trim());
      }
    } catch (e) {
      lastGeminiError = `${model}: ${e.message}`;
    }
  }
  recordError('Gemini', lastGeminiError || 'All free models failed');
  return null;
}

async function analyzeIncomingMessage(psid, userText) {
  const conv = getOrCreateConv(psid);
  const history = conv.messages.slice(-10).map(m => `${m.role}: ${m.text}`).join('\n');
  const activeStatuses = getActiveShareableStatuses();
  const statusBlock = activeStatuses.length
    ? activeStatuses.map(s => `- [Approved Active Status]: ${s.text}`).join('\n')
    : '(No active owner status right now)';
  const kbBlock = state.kbItems.map(i => `Q: ${i.question}\nA: ${i.answer}`).join('\n---\n');

  const prompt = `${state.config.systemPrompt}
Assistant Name: ${state.config.assistantName} | Owner Name: ${state.config.ownerDisplayName}
Default Tone: ${state.config.defaultTone} | Emoji Level: ${state.config.emojiLevel}
Detected Sender Style -> Language: ${conv.prefs.language}, Pronoun: ${conv.prefs.pronoun}

Approved Shareable Live Owner Statuses (USE ONLY IF RELEVANT TO THE QUESTION):
${statusBlock}

Approved Knowledge Base / FAQ:
${kbBlock || '(None)'}

Conversation Summary: ${conv.summary || '(None)'}
Recent Messages:
${history || '(New conversation)'}

Latest Untrusted User Message:
"${userText}"

Tasks:
1. Classify into ONE of: GENERAL, PERSONAL, UNCERTAIN, SENSITIVE, URGENT, COMPLAINT, SPAM, FOLLOW_UP.
2. Rules:
   - If the user asks about the owner's current status/activity/eating/college/availability AND an Approved Active Status above directly answers it, set classification="GENERAL", requires_owner=false, and craft a natural reply in the user's exact language & pronoun using that approved status!
   - If the user asks a personal question (location, plans, eating, college, meeting, phone call, personal decision) and NO Approved Active Status answers it, set classification="PERSONAL", requires_owner=true, suggested_reply="", and generate 3-4 short optional replies in "owner_suggestions" (array of strings) in the user's language/pronoun.
   - If GENERAL or casual greeting/chat (e.g. "ki koris?", "ki khobor?", "Hi", "কেমন আছো?"), set requires_owner=false and write a warm, friend-like reply matching the user's language & pronoun in "suggested_reply" (without inventing physical actions if no active status exists).
   - If UNCERTAIN, SENSITIVE, URGENT, or COMPLAINT: set requires_owner=true and provide 3 short "owner_suggestions".
Return ONLY valid JSON:
{"classification":"GENERAL","confidence":0.95,"language":"bn","requires_owner":false,"reason":"...","suggested_reply":"...","owner_suggestions":["...","...","..."]}`;

  return callGeminiJSON(prompt, 0.65);
}

// --- Pending Reply Escalation with 3-4 Smart Suggestions ---
function createPendingAndNotify(psid, senderName, question, classification, reason, suggestions = []) {
  state.pendingCounter += 1;
  state.stats.escalated += 1;
  const pid = `PR-${state.pendingCounter}`;
  const timeStr = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const cleanSugg = Array.isArray(suggestions) && suggestions.length
    ? suggestions.slice(0, 4)
    : ['হ্যাঁ, ঠিক আছে।', 'না, এখন পারব না।', 'একটু পরে জানাচ্ছি।'];

  state.pendingReplies[pid] = {
    id: pid, psid, senderName, question, classification, reason,
    suggestions: cleanSugg, status: 'WAITING', createdAt: timeStr
  };
  saveState();

  if (tgBot && ADMIN_CHAT_ID) {
    const suggLines = cleanSugg.map((s, idx) => `${idx + 1}. ${s}`).join('\n');
    const msg = `🚨 *ZEVIAN — ${classification} QUESTION*\n\n🆔 Pending ID: \`${pid}\`\n👤 Sender: ${senderName}\n💬 PSID: \`${psid}\`\n🕒 Time: ${timeStr}\n💡 Reason: ${reason}\n\n❓ *Message:*\n${question}\n\n✨ *AI Suggested Replies (1-Tap Send):*\n${suggLines}\n\n📊 Status: WAITING FOR OWNER`;

    const suggRow = cleanSugg.map((_, idx) => ({ text: `✅ #${idx + 1}`, callback_data: `sugg:${pid}:${idx}` }));
    tgBot.sendMessage(ADMIN_CHAT_ID, msg, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          suggRow,
          [{ text: '✍️ Custom Reply', callback_data: `reply:${pid}` }, { text: '🚫 Ignore', callback_data: `ignore:${pid}` }],
          [{ text: '💬 History', callback_data: `view:${psid}` }, { text: '⛔ Block', callback_data: `block:${psid}` }],
          [{ text: '🚀 Open Mini App Composer', web_app: { url: PUBLIC_URL } }]
        ]
      }
    }).catch(() => {});
  }
  return pid;
}

async function deliverReplyToPsid(psid, text, pid = null) {
  const within24h = isWithin24hWindow(psid);
  const res = await callGraph('me/messages', { recipient: { id: psid }, message: { text } });
  if (res && res.message_id) {
    pushHistory(psid, 'Owner', text);
    state.stats.ownerReplied += 1;
    if (pid && state.pendingReplies[pid]) {
      state.pendingReplies[pid].status = 'ANSWERED';
      state.pendingReplies[pid].ownerReply = text;
    }
    saveState();
    return { ok: true, within24h, messageId: res.message_id };
  }
  return { ok: false, within24h, error: res };
}

// --- Meta Webhooks ---
app.get('/webhook', (req, res) => {
  const verifyToken = (process.env.FB_VERIFY_TOKEN || 'safi_page_verify_2026').trim();
  if (req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === verifyToken) {
    return res.status(200).send(req.query['hub.challenge']);
  }
  return res.sendStatus(403);
});

app.post('/webhook', async (req, res) => {
  if (!verifyMetaSignature(req)) {
    recordError('Security', 'Invalid X-Hub-Signature-256');
    return res.sendStatus(403);
  }
  const body = req.body;
  if (body.object !== 'page') return res.sendStatus(404);
  res.status(200).send('EVENT_RECEIVED');
  if (!state.config.masterActive) return;

  for (const entry of body.entry || []) {
    const pageId = entry.id;
    if (entry.messaging && state.config.pageDmEnabled) {
      for (const ev of entry.messaging) {
        const psid = ev.sender?.id, mid = ev.message?.mid;
        if (!psid || psid === pageId || ev.message?.is_echo || state.blockedUsers.includes(psid)) continue;
        if (mid && processedIds.has(mid)) continue;
        if (mid) processedIds.add(mid);
        state.stats.totalIn += 1;

        const senderName = await fetchSenderName(psid);
        getOrCreateConv(psid, senderName);

        if (!ev.message?.text && ev.message?.attachments?.length) {
          const att = ev.message.attachments[0];
          if (att.type === 'image' && ev.message.sticker_id) {
            await callGraph('me/messages', { recipient: { id: psid }, message: { text: '😊👍' } });
            pushHistory(psid, 'User', '[Sticker]');
            pushHistory(psid, 'ZEVIAN', '😊👍');
          } else {
            const label = `[${att.type.toUpperCase()} Attachment] ${att.payload?.url || ''}`;
            pushHistory(psid, 'User', label);
            createPendingAndNotify(psid, senderName, label, 'UNCERTAIN', `User sent ${att.type} media`, ['দেখলাম, ধন্যবাদ!', 'একটু পরে শুনে/দেখে জানাচ্ছি।']);
          }
          continue;
        }

        const text = ev.message?.text;
        if (!text) continue;
        pushHistory(psid, 'User', text);

        await callGraph('me/messages', { recipient: { id: psid }, sender_action: 'typing_on' });
        const aiResult = await analyzeIncomingMessage(psid, text);
        const activeStatuses = getActiveShareableStatuses();

        // Hard backend guard: if obvious personal & no active shareable status, never auto-invent
        if (isObviousPersonal(text) && activeStatuses.length === 0) {
          const sugg = (aiResult && aiResult.owner_suggestions) || ['হ্যাঁ, ঠিক আছে।', 'না, এখন না।', 'একটু পরে জানাচ্ছি।'];
          await callGraph('me/messages', { recipient: { id: psid }, message: { text: 'এই প্রশ্নটির উত্তর আমার Owner দিতে পারবেন। একটু অপেক্ষা করো 😊' } });
          createPendingAndNotify(psid, senderName, text, 'PERSONAL', 'Personal question with no active owner status', sugg);
          continue;
        }

        if (!aiResult) {
          createPendingAndNotify(psid, senderName, text, 'UNCERTAIN', `Gemini error: ${lastGeminiError || 'Unavailable'}`);
          continue;
        }

        const cls = (aiResult.classification || 'UNCERTAIN').toUpperCase();
        const conf = Number(aiResult.confidence || 0);
        if (cls === 'SPAM') continue;

        if ((cls === 'GENERAL' || cls === 'FOLLOW_UP') && !aiResult.requires_owner && conf >= state.config.confidenceThreshold && aiResult.suggested_reply) {
          const replyText = aiResult.suggested_reply.trim();
          await callGraph('me/messages', { recipient: { id: psid }, message: { text: replyText } });
          pushHistory(psid, 'ZEVIAN', replyText);
          state.stats.autoReplied += 1;
          saveState();
          if (tgBot && ADMIN_CHAT_ID) {
            tgBot.sendMessage(ADMIN_CHAT_ID, `💬 *ZEVIAN Auto-Reply (${cls})*\n👤 ${senderName} (\`${psid}\`)\n📩 User: ${text}\n🤖 ZEVIAN: ${replyText}`, {
              parse_mode: 'Markdown',
              reply_markup: { inline_keyboard: [[{ text: '💬 History', callback_data: `view:${psid}` }, { text: '⛔ Block', callback_data: `block:${psid}` }]] }
            }).catch(() => {});
          }
        } else {
          if (cls === 'PERSONAL') {
            await callGraph('me/messages', { recipient: { id: psid }, message: { text: 'এই প্রশ্নটির উত্তর আমার Owner দিতে পারবেন। একটু অপেক্ষা করো 😊' } });
          }
          createPendingAndNotify(psid, senderName, text, cls, aiResult.reason || 'Requires owner approval', aiResult.owner_suggestions || []);
        }
      }
    }

    if (entry.changes) {
      for (const ch of entry.changes) {
        if (ch.field === 'feed' && ch.value?.item === 'comment' && ch.value?.verb === 'add') {
          const cid = ch.value.comment_id, fromId = ch.value.from?.id, fromName = ch.value.from?.name || 'Friend', cText = ch.value.message || '';
          if (!cid || fromId === pageId || !cText || processedIds.has(cid)) continue;
          processedIds.add(cid);
          const aiRes = await analyzeIncomingMessage(`c_${fromId || cid}`, `[Post Comment]: ${cText}`);
          const inboxReply = (aiRes && aiRes.suggested_reply) || `ধন্যবাদ ${fromName}! আপনার কমেন্টের জন্য কৃতজ্ঞতা। কীভাবে সাহায্য করতে পারি?`;
          if (state.config.commentReplyEnabled) await callGraph(`${cid}/comments`, { message: `ধন্যবাদ ${fromName}! আপনার ইনবক্সে বিস্তারিত পাঠিয়ে দেওয়া হয়েছে 😊` });
          if (state.config.commentInboxEnabled) await callGraph(`${pageId}/messages`, { recipient: { comment_id: cid }, message: { text: inboxReply } });
        }
      }
    }
  }
});

// --- Admin & Telegram Mini App Auth Middleware ---
function requireAuth(req, res, next) {
  const pass = (req.headers['x-admin-password'] || '').trim();
  const tgInit = req.headers['x-telegram-init-data'] || '';
  if (pass === ADMIN_PASSWORD || verifyTelegramInitData(tgInit)) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

app.get('/api/admin/overview', requireAuth, (req, res) => {
  getActiveShareableStatuses();
  res.json({
    config: state.config,
    stats: state.stats,
    ownerStatuses: state.ownerStatuses,
    kbItems: state.kbItems,
    pendingReplies: Object.values(state.pendingReplies).reverse(),
    conversations: Object.values(state.conversations),
    blockedUsers: state.blockedUsers,
    errorLogs: state.errorLogs,
    geminiOk: !lastGeminiError,
    lastGeminiError,
    signatureVerification: Boolean(APP_SECRET),
    uptime: Math.floor(process.uptime())
  });
});

app.post('/api/admin/config', requireAuth, (req, res) => {
  state.config = { ...state.config, ...req.body };
  saveState();
  res.json({ ok: true, config: state.config });
});

app.post('/api/admin/status', requireAuth, (req, res) => {
  const { text, visibility, durationMinutes } = req.body || {};
  if (!text) return res.status(400).json({ error: 'Status text required' });
  const st = addOwnerStatus(text, visibility || 'shareable', durationMinutes ? Number(durationMinutes) : null);
  res.json({ ok: true, status: st });
});

app.post('/api/admin/status/revoke', requireAuth, (req, res) => {
  const { id } = req.body || {};
  state.ownerStatuses.forEach(s => { if (!id || s.id === id) s.active = false; });
  saveState();
  res.json({ ok: true });
});

app.post('/api/admin/rewrite', requireAuth, async (req, res) => {
  const { text, mode } = req.body || {};
  if (!text) return res.status(400).json({ error: 'Text required' });
  const result = await callGeminiJSON(
    `Rewrite the following Messenger reply according to instruction "${mode || 'Make it friendlier and natural'}". Keep the same meaning. Original: "${text}". Return JSON: {"rewritten":"..."}`,
    0.7
  );
  res.json({ ok: Boolean(result && result.rewritten), rewritten: result ? result.rewritten : text });
});

app.post('/api/admin/kb', requireAuth, (req, res) => {
  const { question, answer } = req.body || {};
  if (!question || !answer) return res.status(400).json({ error: 'Required' });
  const item = { id: `kb-${Date.now()}`, question: question.trim(), answer: answer.trim() };
  state.kbItems.unshift(item);
  saveState();
  res.json({ ok: true, item });
});

app.delete('/api/admin/kb/:id', requireAuth, (req, res) => {
  state.kbItems = state.kbItems.filter(i => i.id !== req.params.id);
  saveState();
  res.json({ ok: true });
});

app.post('/api/admin/reply', requireAuth, async (req, res) => {
  const { psid, pendingId, text } = req.body || {};
  const targetPsid = pendingId && state.pendingReplies[pendingId] ? state.pendingReplies[pendingId].psid : psid;
  if (!targetPsid || !text) return res.status(400).json({ error: 'Missing target or text' });
  res.json(await deliverReplyToPsid(targetPsid, text.trim(), pendingId || null));
});

app.post('/api/admin/ignore', requireAuth, (req, res) => {
  const { pendingId } = req.body || {};
  if (pendingId && state.pendingReplies[pendingId]) { state.pendingReplies[pendingId].status = 'IGNORED'; saveState(); }
  res.json({ ok: true });
});

app.post('/api/admin/block', requireAuth, (req, res) => {
  const { psid } = req.body || {};
  if (psid && !state.blockedUsers.includes(psid)) { state.blockedUsers.push(psid); saveState(); }
  res.json({ ok: true });
});

app.post('/api/admin/unblock', requireAuth, (req, res) => {
  const { psid } = req.body || {};
  state.blockedUsers = state.blockedUsers.filter(id => id !== psid);
  saveState();
  res.json({ ok: true });
});

app.post('/api/admin/clear-memory', requireAuth, (req, res) => {
  state.conversations = {};
  saveState();
  res.json({ ok: true });
});

// --- Advanced Telegram Control Center ---
if (BOT_TOKEN) {
  tgBot = new TelegramBot(BOT_TOKEN, { polling: true });
  const isOwner = cid => !ADMIN_CHAT_ID || String(cid) === String(ADMIN_CHAT_ID);

  const sendMenu = cid => {
    const waiting = Object.values(state.pendingReplies).filter(p => p.status === 'WAITING').length;
    const activeSt = getActiveShareableStatuses();
    const stLine = activeSt.length ? activeSt[0].text : 'কোনো Active Status নেই';
    tgBot.sendMessage(
      cid,
      `🤖 *ZEVIAN v4.0 Control Center*\n• Master: ${state.config.masterActive ? '✅ ON' : '⏸ PAUSED'} | Gemini: ${lastGeminiError ? '⚠️ Error' : '✅ Ready'}\n• Active Status: _${stLine}_\n• Chats: ${Object.keys(state.conversations).length} | Pending: ${waiting} | Auto-Replies: ${state.stats.autoReplied}`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🚀 Open ZEVIAN Mini App', web_app: { url: PUBLIC_URL } }],
            [{ text: state.config.masterActive ? '⏸ Pause All' : '▶️ Resume All', callback_data: 'toggle' }, { text: '📋 Pending List', callback_data: 'list_pending' }],
            [{ text: '📍 My Status', callback_data: 'show_status' }, { text: '📊 Analytics', callback_data: 'show_analytics' }]
          ]
        }
      }
    );
  };

  tgBot.onText(/\/(start|panel|status)/, m => isOwner(m.chat.id) && sendMenu(m.chat.id));
  tgBot.onText(/\/help/, m => isOwner(m.chat.id) && tgBot.sendMessage(m.chat.id, `📖 *ZEVIAN v4.0 Commands:*\n/status — কন্ট্রোল প্যানেল\n/pending — অপেক্ষমাণ প্রশ্ন\n/inbox — সাম্প্রতিক চ্যাট\n/mystatus — বর্তমান Active Status\n/setstatus <তথ্য> — নতুন Status সেট করুন\n/clearstatus — সব Status বন্ধ করুন\n/reply <PR-ID> <উত্তর>\n/ignore <PR-ID> | /block <PSID>\n/addkb <প্রশ্ন> | <উত্তর>\n/analytics — পরিসংখ্যান\n/testgemini — Gemini চেক`, { parse_mode: 'Markdown' }));

  tgBot.onText(/\/analytics/, m => {
    if (!isOwner(m.chat.id)) return;
    tgBot.sendMessage(m.chat.id, `📊 *ZEVIAN Analytics*\n• Total Incoming: ${state.stats.totalIn}\n• Auto-Replied (AI): ${state.stats.autoReplied}\n• Escalated to Owner: ${state.stats.escalated}\n• Owner Replies Sent: ${state.stats.ownerReplied}\n• Active Conversations: ${Object.keys(state.conversations).length}`, { parse_mode: 'Markdown' });
  });

  tgBot.onText(/\/mystatus/, m => {
    if (!isOwner(m.chat.id)) return;
    const list = getActiveShareableStatuses();
    if (!list.length) return tgBot.sendMessage(m.chat.id, '📍 বর্তমানে কোনো Active Shareable Status নেই।\nনতুন স্ট্যাটাস দিতে লিখুন: `/setstatus আমি বাইরে যাচ্ছি`', { parse_mode: 'Markdown' });
    tgBot.sendMessage(m.chat.id, `📍 *Active Shareable Statuses:*\n\n` + list.map(s => `• \`${s.id}\`: ${s.text} _(Expiry: ${s.expiresLabel})_`).join('\n'), {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [[{ text: '🛑 Clear All Statuses', callback_data: 'clear_statuses' }]] }
    });
  });

  tgBot.onText(/\/clearstatus/, m => {
    if (!isOwner(m.chat.id)) return;
    state.ownerStatuses.forEach(s => { s.active = false; });
    saveState();
    tgBot.sendMessage(m.chat.id, '🛑 সব Active Status বন্ধ করা হয়েছে।');
  });

  function promptStatusConfirmation(chatId, text) {
    pendingDraftStatus = text.trim();
    tgBot.sendMessage(chatId, `📍 *এই তথ্যটি Active Status হিসেবে রাখব?*\n\n_"${pendingDraftStatus}"_`, {
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '✅ Share (1 Hour)', callback_data: 'st_save:share:60' }, { text: '✅ Share (3 Hours)', callback_data: 'st_save:share:180' }],
          [{ text: '✅ Share (6 Hours)', callback_data: 'st_save:share:360' }, { text: '🔒 Keep Private', callback_data: 'st_save:private:360' }],
          [{ text: '❌ Cancel', callback_data: 'st_cancel' }]
        ]
      }
    });
  }

  tgBot.onText(/\/setstatus ([\s\S]+)/, (m, match) => {
    if (!isOwner(m.chat.id)) return;
    promptStatusConfirmation(m.chat.id, match[1]);
  });

  tgBot.onText(/\/inbox/, m => {
    if (!isOwner(m.chat.id)) return;
    const list = Object.values(state.conversations).slice(-8);
    if (!list.length) return tgBot.sendMessage(m.chat.id, '💬 এখনো কোনো কনভারসেশন নেই।');
    const text = list.map(c => `👤 *${c.senderName}* (\`${c.psid}\`) [${c.prefs.language}/${c.prefs.pronoun}]\n└ ${c.messages[c.messages.length - 1]?.text || ''}`).join('\n\n');
    tgBot.sendMessage(m.chat.id, `💬 *Recent Inbox:*\n\n${text}`, { parse_mode: 'Markdown' });
  });

  tgBot.onText(/\/testgemini/, async m => {
    if (!isOwner(m.chat.id)) return;
    const res = await analyzeIncomingMessage('test_owner', 'ki khobor?');
    tgBot.sendMessage(m.chat.id, res ? `✅ *Gemini v4 সচল!*\nClass: \`${res.classification}\` (${res.confidence})\nReply: ${res.suggested_reply}` : `❌ *Gemini এরর:*\n\`${lastGeminiError}\``, { parse_mode: 'Markdown' });
  });

  tgBot.onText(/\/pending/, m => {
    if (!isOwner(m.chat.id)) return;
    const list = Object.values(state.pendingReplies).filter(p => p.status === 'WAITING');
    if (!list.length) return tgBot.sendMessage(m.chat.id, '✅ কোনো Pending প্রশ্ন নেই!');
    list.forEach(p => tgBot.sendMessage(m.chat.id, `🆔 \`${p.id}\` | 👤 ${p.senderName}\n❓ ${p.question}`, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [[{ text: '✍️ Reply', callback_data: `reply:${p.id}` }, { text: '🚫 Ignore', callback_data: `ignore:${p.id}` }]] }
    }));
  });

  tgBot.onText(/\/addkb ([\s\S]+)/, (m, match) => {
    if (!isOwner(m.chat.id)) return;
    const parts = match[1].split('|');
    state.kbItems.unshift({ id: `kb-${Date.now()}`, question: (parts[0] || '').trim(), answer: (parts[1] || parts[0] || '').trim() });
    saveState();
    tgBot.sendMessage(m.chat.id, '✅ Knowledge Base-এ নতুন FAQ যুক্ত হয়েছে!');
  });

  tgBot.onText(/\/block (\S+)/, (m, match) => {
    if (!isOwner(m.chat.id)) return;
    const uid = match[1].trim();
    if (!state.blockedUsers.includes(uid)) state.blockedUsers.push(uid);
    saveState();
    tgBot.sendMessage(m.chat.id, `⛔ \`${uid}\` ব্লক করা হয়েছে।`, { parse_mode: 'Markdown' });
  });

  tgBot.onText(/\/reply (\S+) ([\s\S]+)/, async (m, match) => {
    if (!isOwner(m.chat.id)) return;
    const target = match[1].trim(), answerText = match[2].trim();
    const pid = state.pendingReplies[target] ? target : null;
    const psid = pid ? state.pendingReplies[pid].psid : target;
    const res = await deliverReplyToPsid(psid, answerText, pid);
    tgBot.sendMessage(m.chat.id, res.ok ? '✅ উত্তর সফলভাবে পাঠানো হয়েছে!' : `❌ পাঠানো যায়নি: \`${JSON.stringify(res.error)}\``, { parse_mode: 'Markdown' });
  });

  tgBot.on('message', async m => {
    if (!isOwner(m.chat.id) || !m.text || m.text.startsWith('/')) return;
    const txt = m.text.trim();
    if (activeReplyPendingId) {
      const pid = activeReplyPendingId;
      activeReplyPendingId = null;
      const item = state.pendingReplies[pid];
      if (!item || item.status !== 'WAITING') return tgBot.sendMessage(m.chat.id, '⚠️ এই প্রশ্নটি ইতিমধ্যেই সম্পন্ন।');
      const res = await deliverReplyToPsid(item.psid, txt, pid);
      return tgBot.sendMessage(m.chat.id, res.ok ? `✅ উত্তর *${item.senderName}*-কে (\`${pid}\`) পাঠানো হয়েছে!` : `❌ পাঠানো যায়নি: \`${JSON.stringify(res.error)}\``, { parse_mode: 'Markdown' });
    }
    // Natural Owner Status Auto-Detection!
    if (STATUS_TRIGGER_CUES.some(cue => txt.includes(cue))) {
      promptStatusConfirmation(m.chat.id, txt);
    }
  });

  tgBot.on('callback_query', async q => {
    const cid = q.message.chat.id;
    if (!isOwner(cid)) return;
    const data = q.data || '';

    if (data === 'toggle') { state.config.masterActive = !state.config.masterActive; saveState(); sendMenu(cid); }
    else if (data === 'show_status') {
      const list = getActiveShareableStatuses();
      tgBot.sendMessage(cid, list.length ? list.map(s => `📍 \`${s.id}\`: ${s.text} (${s.expiresLabel})`).join('\n') : '📍 কোনো Active Status নেই।', { parse_mode: 'Markdown' });
    } else if (data === 'show_analytics') {
      tgBot.sendMessage(cid, `📊 Total: ${state.stats.totalIn} | Auto-AI: ${state.stats.autoReplied} | Escalated: ${state.stats.escalated} | Owner Sent: ${state.stats.ownerReplied}`);
    } else if (data === 'clear_statuses') {
      state.ownerStatuses.forEach(s => { s.active = false; }); saveState();
      tgBot.sendMessage(cid, '🛑 সব Active Status বন্ধ করা হয়েছে।');
    } else if (data.startsWith('st_save:')) {
      const [, vis, mins] = data.split(':');
      if (pendingDraftStatus) {
        const st = addOwnerStatus(pendingDraftStatus, vis === 'private' ? 'private' : 'shareable', Number(mins));
        pendingDraftStatus = null;
        tgBot.sendMessage(cid, `✅ Status *${st.id}* (${st.visibility}, ${st.expiresLabel}) চালু হয়েছে!\n_"${st.text}"_`, { parse_mode: 'Markdown' });
      }
    } else if (data === 'st_cancel') {
      pendingDraftStatus = null;
      tgBot.sendMessage(cid, '❌ Status বাতিল করা হয়েছে।');
    } else if (data === 'list_pending') {
      const list = Object.values(state.pendingReplies).filter(p => p.status === 'WAITING');
      tgBot.sendMessage(cid, list.length ? list.map(p => `• \`${p.id}\` (${p.senderName}): ${p.question}`).join('\n') : '✅ কোনো Pending প্রশ্ন নেই।', { parse_mode: 'Markdown' });
    } else if (data.startsWith('sugg:')) {
      const [, pid, idxStr] = data.split(':');
      const item = state.pendingReplies[pid];
      const chosen = item && item.suggestions && item.suggestions[Number(idxStr)];
      if (!item || item.status !== 'WAITING' || !chosen) {
        tgBot.sendMessage(cid, `⚠️ \`${pid}\` ইতিমধ্যেই সম্পন্ন।`, { parse_mode: 'Markdown' });
      } else {
        const res = await deliverReplyToPsid(item.psid, chosen, pid);
        tgBot.sendMessage(cid, res.ok ? `✅ 1-Tap উত্তর *${item.senderName}*-কে পাঠানো হয়েছে:\n_"${chosen}"_` : `❌ পাঠানো যায়নি`, { parse_mode: 'Markdown' });
      }
    } else if (data.startsWith('reply:')) {
      const pid = data.split(':')[1];
      if (!state.pendingReplies[pid] || state.pendingReplies[pid].status !== 'WAITING') tgBot.sendMessage(cid, `⚠️ \`${pid}\` ইতিমধ্যেই সম্পন্ন।`, { parse_mode: 'Markdown' });
      else { activeReplyPendingId = pid; tgBot.sendMessage(cid, `✍️ *${state.pendingReplies[pid].senderName}*-এর প্রশ্নের (\`${pid}\`) উত্তর সরাসরি লিখুন:\n\n❓ _"${state.pendingReplies[pid].question}"_`, { parse_mode: 'Markdown' }); }
    } else if (data.startsWith('ignore:')) {
      const pid = data.split(':')[1];
      if (state.pendingReplies[pid]) { state.pendingReplies[pid].status = 'IGNORED'; saveState(); tgBot.sendMessage(cid, `🚫 \`${pid}\` ইগনোর করা হয়েছে।`, { parse_mode: 'Markdown' }); }
    } else if (data.startsWith('block:')) {
      const psid = data.split(':')[1];
      if (!state.blockedUsers.includes(psid)) { state.blockedUsers.push(psid); saveState(); }
      tgBot.sendMessage(cid, `⛔ ইউজার \`${psid}\` ব্লক করা হয়েছে।`, { parse_mode: 'Markdown' });
    } else if (data.startsWith('view:')) {
      const psid = data.split(':')[1], conv = state.conversations[psid];
      const lines = conv ? conv.messages.slice(-10).map(m => `[${m.time}] *${m.role}:* ${m.text}`).join('\n') : 'হিস্ট্রি নেই।';
      tgBot.sendMessage(cid, `💬 *History (${conv ? conv.senderName : psid}):*\n\n${lines}`, { parse_mode: 'Markdown' });
    }
    tgBot.answerCallbackQuery(q.id, { text: 'Done!' });
  });
}

app.get('/health', (req, res) => res.json({
  ok: true,
  version: '4.0.0',
  masterActive: state.config.masterActive,
  geminiOk: !lastGeminiError,
  activeStatuses: getActiveShareableStatuses().length,
  pendingCount: Object.values(state.pendingReplies).filter(p => p.status === 'WAITING').length,
  uptime: Math.floor(process.uptime())
}));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('ZEVIAN v4.0 Ultimate Assistant running on port', PORT));
